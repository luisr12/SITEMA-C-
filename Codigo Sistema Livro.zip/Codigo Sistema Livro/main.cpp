#include <iostream>

char senha;

int main (){
	printf("-----------------------------------CESAR LIVRO CAIXA------------------------------------\n ");
	
	printf("Login:    ");
	scanf("%c",&senha);
	do{

	if(senha=="1234"){
		printf("Seja Bem vindo Cesar");
	}
	else{
		printf("Tente novamente");
	}
		}while(senha<>true)
}
